<?php


class AuthModel extends CI_Model
{
    function getUser($data)
    {
        $query = $this->db->get_where("admin", $data);
        return $query->result_array();
//        return $this->db->get_where("admin", $data)->result_array;
    }
}