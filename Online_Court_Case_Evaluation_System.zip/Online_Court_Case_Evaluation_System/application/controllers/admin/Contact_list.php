<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Contact_list extends Admin_Controller {
   public function __construct()
   {
      parent::__construct();
      // set timezone
      date_default_timezone_set('Asia/Karachi');
      
      $this->load->model('news_model');
   }
   
   public function index()
   {
	   	// add css & js files
	   	$this->template->add_css('assets/plugins/datatables/jquery.dataTables.min.css');
	   	$this->template->add_js('assets/plugins/datatables/jquery.dataTables.min.js');
	   	$this->template->add_js('assets/plugins/datatables/dataTables.bootstrap.js');
   	
   		// get upload images
   		$data['messages'] = $this->news_model->get_all_messages();
   		
   		$this->template->set_title('All Inquiries');
   		$this->template->loadview('templates/default_admin','backend/messages/index', $data);
   }

   public function delete($id) {

   		$this->news_model->delete_msg($id);
   		$this->session->set_flashdata('message','This news have deleted.');
       setMyMessage("Record has been deleted successfully");
   		redirect( base_url('admin/contact_list') );
   }

}