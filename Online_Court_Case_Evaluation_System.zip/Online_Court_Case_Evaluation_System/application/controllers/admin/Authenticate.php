<?php


class Authenticate extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("AuthModel");
        $this->load->library("Session");
    }

    public function index()
    {
        $name = $this->input->post("identity");
        $password = $this->input->post("password");

        $userInfo = array("user" => $this->input->post("identity"), "pass" => $this->input->post("password"));
        $response = $this->AuthModel->getUser($userInfo);

        if (empty($response)) {
            redirect("admin/auth/login", "refresh");
        } else {
            $this->session->set_userdata($userInfo);
            redirect("admin/dashboard", "refresh");
        }

    }
}