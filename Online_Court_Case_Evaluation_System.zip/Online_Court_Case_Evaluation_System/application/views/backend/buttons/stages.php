<?php defined('BASEPATH') or die('Restricted access');?>

<div class="hidden-print">
	<div class="button-list">
		<a href="<?php echo base_url('admin/stages/add')?>" class="btn btn-primary btn-rounded" data-toggle="tooltip" title="Add new stage name"><i class="fa fa-plus-circle"></i> Add Stage</a>
	</div>
</div>