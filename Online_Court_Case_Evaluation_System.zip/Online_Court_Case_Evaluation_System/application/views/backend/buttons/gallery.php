<?php defined('BASEPATH') or die('Restricted access');?>

<div class="hidden-print card-box">
	<div class="button-list">
		<a href="<?php echo base_url('admin/gallery')?>" class="btn btn-primary btn-rounded" data-toggle="tooltip" title="photo gallery"><i class="fa fa-list-ul"></i> Photo Gallery</a>
		
		<a href="<?php echo base_url('admin/gallery/add')?>" class="btn btn-primary btn-rounded" data-toggle="tooltip" title="Add new photo"><i class="fa fa-plus-circle"></i> Add Photo</a>
	</div>
</div>