<?php defined('BASEPATH') or die('Restricted access');?>

	<div class="btn-group">
		<!-- <a href="<?php echo base_url()?>admin/sessions_courts_add_cases/add_crapeal" class="custom-menu btn" data-toggle="tooltip" title="Add Cr. Apeal Case in Sessions Courts!"><span class="glyphicon glyphicon-plus"></span>Add Cr. Apeal</a> -->
		
		<a href="<?php echo base_url()?>admin/sessions_courts_add_cases/add_criminal" class="custom-menu btn" data-toggle="tooltip" title="Add Cr. Case in Sessions Courts!"><span class="glyphicon glyphicon-plus"></span>Add Criminal Case</a>
		
		<a href="<?php echo base_url()?>admin/sessions_courts_add_cases/add_civil" class="custom-menu btn" data-toggle="tooltip" title="Add Civil Case in Sessions Courts!"><span class="glyphicon glyphicon-plus"></span>Add Civil Case</a>
	</div>