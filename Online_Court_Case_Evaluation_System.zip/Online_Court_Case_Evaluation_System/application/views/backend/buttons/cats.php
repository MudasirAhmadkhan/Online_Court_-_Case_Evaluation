<?php defined('BASEPATH') or die('Restricted access');?>

<div class="hidden-print">
	<div class="button-list">
		<a href="<?php echo base_url('admin/categories/add')?>" class="btn btn-primary btn-rounded" data-toggle="tooltip" title="Add Category of cases!"><i class="fa fa-plus-circle"></i> Add Category</a>
	</div>
</div>