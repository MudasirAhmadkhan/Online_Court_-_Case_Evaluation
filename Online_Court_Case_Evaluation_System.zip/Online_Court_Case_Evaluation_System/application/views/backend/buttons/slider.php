<?php defined('BASEPATH') or die('Restricted access');?>

<div class="hidden-print card-box">
	<div class="button-list">
		<a href="<?php echo base_url('admin/slider')?>" class="btn btn-primary btn-rounded" data-toggle="tooltip" title="photo gallery"><i class="fa fa-list-ul"></i> Slider Images</a>
		
		<a href="<?php echo base_url('admin/slider/add')?>" class="btn btn-primary btn-rounded" data-toggle="tooltip" title="Add new photo"><i class="fa fa-plus-circle"></i> Add Image</a>
	</div>
</div>