<?php defined('BASEPATH') or die('Restricted access');?>

<div class="hidden-print card-box">
	<div class="button-list">
		<a href="<?php echo base_url('admin/auth')?>" class="btn btn-default btn-rounded" data-toggle="tooltip" title="List of Users!"><i class="fa fa-th-list"></i> User List</a>
		<a href="<?php echo base_url('admin/auth/create_user')?>" class="btn btn-primary btn-rounded" data-toggle="tooltip" title="Create user"><i class="fa fa-plus-circle"></i> Create User</a>
	</div>
</div>