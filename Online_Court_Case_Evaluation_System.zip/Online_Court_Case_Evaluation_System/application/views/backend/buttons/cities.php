<?php defined('BASEPATH') or die('Restricted access');?>
<div class="hidden-print card-box">
	<div class="button-list">
		<a href="<?php echo base_url('admin/cities')?>" class="btn btn-default btn-rounded" data-toggle="tooltip" title="List of Cities"><i class="fa fa-th-list"></i> Cities</a>
		<a href="<?php echo base_url('admin/cities/add')?>" class="btn btn-primary btn-rounded" data-toggle="tooltip" title="Add City"><i class="fa fa-plus-circle"></i> Add City</a>
	</div>
</div>