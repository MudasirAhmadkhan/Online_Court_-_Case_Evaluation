<?php defined('BASEPATH') or die('Restricted access');?>

	<div class="btn-group">
		<a href="<?php echo base_url()?>admin/manage_sessions_courts/courts" class="custom-menu btn"><span class="glyphicon glyphicon-th-list margin-right15"></span>Courts Name</a>
		<a href="<?php echo base_url()?>admin/manage_sessions_courts/add_court" class="custom-menu btn"><span class="glyphicon glyphicon-plus margin-right15"></span>New Court's Name</a>
		<a href="<?php echo base_url()?>admin/manage_sessions_courts/types" class="custom-menu btn"><span class="glyphicon glyphicon-th-list margin-right15"></span>Designations</a>
		<a href="<?php echo base_url()?>admin/manage_sessions_courts/add_type" class="custom-menu btn"><span class="glyphicon glyphicon-plus margin-right15"></span>New Designation</a>			
	</div>
