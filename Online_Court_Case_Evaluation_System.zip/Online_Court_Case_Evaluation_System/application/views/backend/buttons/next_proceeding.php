<?php defined('BASEPATH') or die('Restricted access');?>

<div class="hidden-print">
	<div class="button-list">
		<a href="<?php echo base_url('admin/next_proceeding/add')?>" class="btn btn-primary btn-rounded" data-toggle="tooltip" title="Add Next Proceeding!"><i class="fa fa-plus-circle"></i> Add Next Proceeding</a>
	</div>
</div>