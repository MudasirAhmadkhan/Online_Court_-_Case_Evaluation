<?php defined('BASEPATH') or die('Restricted access');?>
<div class="hidden-print card-box">
	<div class="button-list">
		<a href="<?php echo base_url('admin/police_stations')?>" class="btn btn-default btn-rounded" data-toggle="tooltip" title="List of Police Stations"><i class="fa fa-th-list"></i> Police Stations</a>
		<a href="<?php echo base_url('admin/police_stations/add')?>" class="btn btn-primary btn-rounded" data-toggle="tooltip" title="Add New Police Stations"><i class="fa fa-plus-circle"></i> Add Police Station</a>
	</div>
</div>