<?php defined('BASEPATH') or die('Restricted access');?>

<div class="hidden-print card-box">
	<div class="button-list">
		<a href="<?php echo base_url('admin/news')?>" class="btn btn-primary btn-rounded" data-toggle="tooltip" title="Manage All News"><i class="fa fa-list-ul"></i> All News</a>
		
		<a href="<?php echo base_url('admin/news/add')?>" class="btn btn-primary btn-rounded" data-toggle="tooltip" title="Add News"><i class="fa fa-plus-circle"></i> Add News</a>
	</div>
</div>