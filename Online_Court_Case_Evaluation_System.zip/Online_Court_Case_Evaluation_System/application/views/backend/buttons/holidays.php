<?php defined('BASEPATH') or die('Restricted access');?>

<div class="hidden-print card-box">
	<div class="button-list">
		<a href="<?php echo base_url('admin/holidays')?>" class="btn btn-primary btn-rounded" data-toggle="tooltip" title="List All Evnets"><i class="fa fa-list-ul"></i> Event List</a>
		
		<a href="<?php echo base_url('admin/holidays/add')?>" class="btn btn-primary btn-rounded" data-toggle="tooltip" title="Add new event & date"><i class="fa fa-plus-circle"></i> Add Event & Date</a>
	</div>
</div>