<?php defined('BASEPATH') or die('Restricted access');?>

	<div class="col-md-12">
		<h1 class="text-center">Manage Sessions Courts</h1>
		<hr>
	</div>
	
