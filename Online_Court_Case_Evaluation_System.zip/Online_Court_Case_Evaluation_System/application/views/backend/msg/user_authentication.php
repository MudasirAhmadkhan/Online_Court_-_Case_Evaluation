<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<div class="container">
	<div class="col-md-12">
		<div class="alert alert-warning alert-dismissible fade in margin15" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">�</span></button>
			<strong>Message</strong> <p>You are not authorized user!</p>
		</div>
	</div>
</div>