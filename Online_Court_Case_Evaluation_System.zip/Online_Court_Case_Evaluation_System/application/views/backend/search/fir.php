<?php defined('BASEPATH') or die('Restricted access'); ?>

<div class="row">

	<span style="display: block;" class="bounceIn animated">

		<div class="col-md-6 col-md-offset-3">

			<div class="panel panel-color panel-custom">

				<div class="panel-heading">
					<h3 class="panel-title">FIR Details</h3>
				</div>

                <form id="fir-form">
				<div class="panel-body">
<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
       value="<?php echo $this->security->get_csrf_hash(); ?>">
                    <!--					--><?php //echo form_open(base_url('admin/cause_list/view'));?>

						<div class="form-group ">
							<div class="row">
								<div class="col-md-12">
                                    <label>police station <span style="color: red">*</span></label>
                                    <select class="form-control" name="police-station">
                                        <option value="1">سول لائن</option>
                                        <option value="2">ریل بازار</option>
                                        <option value="3">کوتوالی</option>
                                        <option value="4">جھنگ بازار</option>
                                        <option value="5">وویمن</option>
                                        <option value="6">گلبرگ</option>
                                        <option value="7">غلام محمد آباد</option>
                                        <option value="8">رضا آباد</option>
                                        <option value="9">پیپلز کالونی</option>
                                        <option value="10">مدینہ ٹائون</option>
                                        <option value="11">سرگودھا روڈ</option>
                                        <option value="12">منصورہ آباد</option>
                                        <option value="13">نشاط آباد</option>
                                        <option value="14">ملت ٹائون</option>
                                        <option value="15">چک جھمرہ</option>
                                        <option value="16">ساہیانوالہ</option>
                                        <option value="17">بٹالہ کالونی</option>
                                        <option value="18">ڈی ٹائپ کالونی</option>
                                        <option value="19">فیکٹری ایریا</option>
                                        <option value="20">سمن آباد</option>
                                        <option value="21">ڈجکوٹ</option>
                                        <option value="22">صدر</option>
                                        <option value="23">ٹھیکری والا</option>
                                        <option value="24">ساندل بار</option>
                                        <option value="25">سٹی جڑانوالہ</option>
                                        <option value="26">صدر جڑانوالہ</option>
                                        <option value="27">ستیانہ</option>
                                        <option value="28">روڈالہ روڈ</option>
                                        <option value="29">لنڈیوالہ</option>
                                        <option value="30">بلوچنی</option>
                                        <option value="31">سٹی سمندری</option>
                                        <option value="32">صدر سمندری</option>
                                        <option value="33">مریدوالا</option>
                                        <option value="34">ترکھانی</option>
                                        <option value="35">سٹی تاندلیانوالہ</option>
                                        <option value="36">صدر تاندلیانوالہ</option>
                                        <option value="37">باہلک</option>
                                        <option value="38">گڑھ</option>
                                        <option value="39">ماموں کانجن</option>
                                        <option value="40">ریلوے فیصل آباد</option>
                                        <option value="41">اے این ایف</option>
                                        <option value="42">ایف آئی اے</option>
                                        <option value="43">اینٹی کرپشن</option>
                                    </select>
								</div>
							</div>
						</div>

						<div class="form-group ">
							<div class="row">
                                <div class="col-md-6">
									<label>FIR number <span style="color: red">*</span></label>
										<input type="text" name="fir-number" placeholder="i.e fir-007"
                                               class="form-control" maxlength="15" required>
									<?php echo form_error('ndoh', '<div class="error">', '</div>'); ?>
								</div>
								<div class="col-md-6">
									<label>Date of creation <span style="color: red">*</span></label>
										<input type="date" name="creation-date" class="form-control" required>
									<?php echo form_error('ndoh', '<div class="error">', '</div>'); ?>
								</div>
							</div>
						</div>


						<div class="form-group m-b-0">
							<div class="col-md-12">
								<button type="submit"
                                        class="btn btn-custom btn-primary btn-rounded btn-lg"> Submit</button>
							</div>
						</div>

                    <!--					--><?php //echo form_close(); ?>
				</div>
                    </form>
                    <p id="add-status" style="color: green"></p>
			</div>
		</div>
	</span>
</div>

<script>
    jQuery(document).ready(function () {
        jQuery('#datepicker').datepicker({
            autoclose: true,
            todayHighlight: true,
            daysOfWeekDisabled: '0',
            daysOfWeekHighlighted: '0,5',
            //    startDate: '+0d',
        });
    });
</script>