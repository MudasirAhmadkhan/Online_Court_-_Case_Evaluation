<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<div class="row">
	<div class="col-sm-12">
		<div class="card-box">
			<table id="datatable" class="table table-striped table-bordered">
			
				<thead>
					<tr>
						<th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Subject</th>
                        <th>Message</th>
						<th class="hidden-print">Action</th>
					</tr>
				</thead>
				<tbody>
					<?php $i=1;?>
					<?php foreach ($messages as $item ) : ?>
					<tr class="text-center">
						<td><?php echo $i++;?></td>
						<td class="text-left"><?php echo $item->name; ?></td>
						<td class="text-left"><?php echo $item->email; ?></td>
						<td class="text-left"><?php echo $item->subject; ?></td>
						<td class="text-left"><?php echo $item->message; ?></td>
						<td class="hidden-print">
							<p class="m-t-10 btn-group-xs">
                                <?php if (getUserRole() !== 'CLERK'){?> <a class="btn btn-danger btn-custom" href="<?php echo base_url('admin/contact_list/delete/'.$item->id); ?>" onclick="return confirm('Are you sure you want to delete this?');" data-toggle="tooltip" title="" data-original-title="Delete"><i class="fa fa-trash-o"></i></a> <?php }?>
							</p>
						</td>
					</tr>
					<?php endforeach; ?>
					
				</tbody>
				
			</table>
		</div>
	</div>

	
</div>
                              

<script type="text/javascript">
	$(document).ready(function() {
    	$('#datatable').dataTable();
	} );
</script>