<!-- <h2><?php echo lang('login_heading');?></h2>
<p><?php echo lang('login_subheading');?></p>-->

<!--<div id="infoMessage" style="color: red"><?php /*echo $message;*/?></div>-->

<?php echo form_open(base_url('admin/auth/signup'), 'class="form-horizontal m-t-20"'); ?>

<div class="form-group">
    <div class="col-xs-12">
        <?php echo form_input($first_name);?>
        <div id="infoMessage" style="color: red"><?php echo form_error('first_name'); ?></div>
    </div>
</div><div class="form-group">
    <div class="col-xs-12">
        <?php echo form_input($last_name);?>
        <div id="infoMessage" style="color: red"><?php echo form_error('last_name'); ?></div>
    </div>
</div><div class="form-group">
    <div class="col-xs-12">
        <?php echo form_input($email);?>
        <div id="infoMessage" style="color: red"><?php echo form_error('email'); ?></div>
    </div>
</div><div class="form-group">
    <div class="col-xs-12">
        <?php echo form_dropdown('role', $role, 'WEB ADMIN', "class='form-control'");?>
    </div>
</div><div class="form-group">
    <div class="col-xs-12">
        <?php echo form_input($phone);?>
        <div id="infoMessage" style="color: red"><?php echo form_error('phone'); ?></div>
    </div>
</div><div class="form-group">
    <div class="col-xs-12">
        <?php echo form_input($password);?>
        <div id="infoMessage" style="color: red"> <?php echo form_error('password'); ?></div>
    </div>
</div>


        
        <div class="form-group">
        	<div class="col-xs-12">
          		<?php echo form_input($password_confirm);?>
                <div id="infoMessage" style="color: red"><?php echo form_error('password_confirm'); ?></div>
          	</div>
        </div>

       
       <div class="form-group text-center m-t-40">
			<div class="col-xs-12">
            	<button class="btn btn-pink btn-block text-uppercase waves-effect waves-light" type="submit">Sign Up</button>
           	</div>
       </div>

<div class="form-group m-t-30 m-b-0">
    <div class="col-sm-12">
        <p>Already have an account? <a href="<?php echo base_url('admin/auth/login'); ?>" class="text-primary m-l-5"><b>Sign in</b></a></p>

    </div>
</div>

	
<?php echo form_close();?>