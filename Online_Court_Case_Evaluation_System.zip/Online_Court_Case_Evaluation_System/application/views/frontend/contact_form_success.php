<?php defined('BASEPATH') or die('Restricted Access'); ?>
<div class="container">
    <div class="row">


	<span style="display: block;" class="bounceIn animated">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-color panel-custom">
				<div class="panel-heading">
					<h3 class="panel-title">Contact Us</h3>
				</div>

				<div class="panel-body">


            <fieldset>

                <?php
                    echo $this->session->flashdata('msg12');
                ?>
            <div class="form-group">
                <div class="col-md-12">
                    <a href="<?php echo base_url()?>contact_us" ><input name="submit" type="button" class="btn btn-primary col-md-12" value=" Back to Contact " /></a>
                </div>
            </div>
            </fieldset>

				</div>
			</div>
		</div>
	</span>

    </div>
</div>