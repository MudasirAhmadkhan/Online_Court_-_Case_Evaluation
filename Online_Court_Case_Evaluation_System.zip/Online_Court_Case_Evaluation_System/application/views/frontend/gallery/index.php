<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<div class="container">
	<div class="row">
		<h2>Gallery</h2>
	
			<div class="col-md-12">
				<div class="row">
				</div>
			</div>
				
			</div>
		</div>
	</div>
</div>