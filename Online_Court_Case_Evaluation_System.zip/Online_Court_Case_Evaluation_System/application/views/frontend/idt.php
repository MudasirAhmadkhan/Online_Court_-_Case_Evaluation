<div class="row">
    <div class="col-lg-12">
        <div class="col-lg-16" style="margin-top: 40px"><h2>Designed & Developed by@</h2></div>
        <p style="font-size:15px;"><b>Mudasir Ahmad Khan &nbsp;------------------------------------ ID: SE120192023</b></p><br>
        <img height="200p" width="200" src="<?php echo base_url('assets/images/muddasir.jpeg')?>"><br>
        <br><p style="font-size:15px;"><b>Alyan Zaib   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;----------------------------------- ID: SE120192007</b></p><br>
        <img height="200p" width="200" src="<?php echo base_url('assets/images/Alyan.jpeg')?>"><br>
        <br><p style="font-size:20px;"><b>BS SOFTWARE ENGINEERING (2019-2023)</b></p>
        <div class="col-lg-16" style="margin-top: 40px"><marquee><h2 style="color: #0000ff;">KOHAT UNIVERSITY OF SCIENCE & TECHNOLOGY</h2></marquee></div>
    </div>
</div>