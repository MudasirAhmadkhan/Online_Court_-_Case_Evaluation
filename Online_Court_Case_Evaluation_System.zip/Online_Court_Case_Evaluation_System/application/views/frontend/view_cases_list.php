<?php defined('BASEPATH') or die('Restrited Access');

echo "View Cases list";