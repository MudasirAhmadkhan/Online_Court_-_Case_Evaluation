<?php defined('BASEPATH') OR exit('No direct script access allowed');
   
	$config['protocol'] = 'mail';
	$config['smtp_host'] = 'host201003.comsatshosting.com';
	$config['smtp_port'] = '465';
	$config['smtp_user'] = 'admin@dsjfaisalabad.gov.pk';
	$config['smtp_pass'] = 'DSJfsd9292';
	$config['mailtype'] = 'html';
	$config['charset'] = 'iso-8859-1';
	$config['wordwrap'] = TRUE;
	$config['newline'] = "\r\n";
    
?>