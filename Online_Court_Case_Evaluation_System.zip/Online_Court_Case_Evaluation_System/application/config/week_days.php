<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['week_days'] = array(
		'Mon' => 'سوموار',
		'Tue' => 'منگل',
		'Wed' => 'بدھ',
		'Thu' => 'جمعرات',
		'Fri' => 'جمتہ المبارک',
		'Sat' => 'ہفتہ',
		'Sun' => 'اتوار'
);

