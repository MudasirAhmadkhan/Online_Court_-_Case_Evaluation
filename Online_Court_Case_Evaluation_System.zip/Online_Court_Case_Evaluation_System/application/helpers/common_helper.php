<?php
/**
 * Generate GUID based on microtime and uniqid rand id
 * @return string
 */
function generateGUID()
{
	$s = strtoupper(md5(uniqid(rand(), true) . microtime()));
	$guidText = strtolower(
		substr($s, 0, 8) . '-' .
		substr($s, 8, 4) . '-' .
		substr($s, 12, 4) . '-' .
		substr($s, 16, 4) . '-' .
		substr($s, 20));
	return $guidText;
}

/**
 * getSupportedFileExtByMime
 * @param int $mime
 *
 * @return mixed|null
 */



if (!function_exists('dd')) {
	function dd()
	{
		echo '<pre>';
		array_map(function ($x) {
			print_r($x);
		}, func_get_args());
		echo '</pre>';
		die;
	}
}

if (!function_exists('getUserRole')) {
    function getUserRole()
    {
        $CI = &get_Instance();
        $query = $CI->db->select('role')
            ->where('id', $CI->session->userdata('user_id'))
            ->limit(1)
            ->order_by('id', 'desc')
            ->get('users');

        $data = $query->row();
        return $data->role;
    }
}

if (!function_exists('getSetMessage')) {
    function getSetMessage($messageType=null, $name=null, $value=null, $type=null)
    {
        if($name==null){
            return;
        }
        if($type=='setMessage'){
            setcookie ($name,$value,time()+ 5, '/');
            return true;
        }else{
            if(isset($_COOKIE[$name])){
                    if($messageType=='error'){
                        echo '<div class="alert alert-warning" role="alert">'.$_COOKIE[$name],'
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                            </button>
                        </div>';

                    }else{
                            echo '<div class="alert alert-success" role="alert">'.$_COOKIE[$name],'
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                            </button>
                        </div>';
                    }
            }else{
                echo "";
            }
        }

    }
}

if (!function_exists('getMyMessage')) {
    function getMyMessage()
    {
        if(isset($_COOKIE['message'])){
               echo '<div class="alert alert-success" role="alert">'.$_COOKIE['message'],'
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                            </button>
                        </div>';

        }else{
            echo "";
        }
        setcookie ('message','',time()- 5, '/');
    }
}

if (!function_exists('setMyMessage')) {
    function setMyMessage($value=null)
    {
        if($value==null){
            return;
        }
        setcookie ('message',$value,time()+ 5, '/');
        return true;

    }
}